# 🚀 دليل النشر على Render

## المتطلبات الأساسية

قبل البدء، تأكد من توفر:
- حساب على [Render.com](https://render.com)
- مفاتيح MEXC API (API Key & Secret Key)
- Telegram Bot Token من [@BotFather](https://t.me/botfather)
- معرف المحادثة Telegram Chat ID

## خطوات النشر

### 1. إنشاء Background Worker

قم بتسجيل الدخول إلى Render وانقر على **New** ثم اختر **Background Worker** (وليس Web Service).

### 2. ربط المستودع

اختر مستودع GitHub الخاص بك: `mraboodaiplus-eng/Telegram-bot`

### 3. إعدادات المشروع

قم بتعيين الإعدادات التالية:

| الإعداد | القيمة |
|--------|-------|
| **Name** | omega-predator-bot |
| **Environment** | Python 3 |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | سيتم قراءته تلقائيًا من Procfile |

### 4. تعيين المتغيرات البيئية

في قسم **Environment Variables**، أضف المتغيرات التالية:

| المفتاح | القيمة | الوصف |
|---------|--------|-------|
| `MEXC_API_KEY` | `your_api_key_here` | مفتاح API من MEXC |
| `MEXC_SECRET_KEY` | `your_secret_key_here` | المفتاح السري من MEXC |
| `TELEGRAM_BOT_TOKEN` | `your_bot_token_here` | توكن البوت من BotFather |
| `TELEGRAM_CHAT_ID` | `your_chat_id_here` | معرف المحادثة الخاص بك |
| `LOG_LEVEL` | `INFO` | مستوى التسجيل (اختياري) |

### 5. النشر

انقر على **Create Background Worker** وانتظر حتى يكتمل البناء والنشر.

## التحقق من التشغيل

### 1. مراقبة Logs

في لوحة تحكم Render، انتقل إلى تبويب **Logs** لمراقبة نشاط البوت.

يجب أن ترى رسائل مثل:
```
🎯 Omega Predator Trading Bot
✅ القائمة البيضاء: BTCUSDT, ETHUSDT
✅ عتبة الشراء: 5.0%
✅ عتبة البيع: 3.0%
```

### 2. اختبار Telegram

أرسل `/start` للبوت عبر Telegram. يجب أن يرد بطلب تحديد مبلغ الصفقة.

## استكشاف الأخطاء

### المشكلة: البوت لا يستجيب

**الحل:**
- تحقق من صحة `TELEGRAM_BOT_TOKEN` و `TELEGRAM_CHAT_ID`
- راجع Logs في Render للتحقق من الأخطاء

### المشكلة: فشل الاتصال بـ MEXC

**الحل:**
- تحقق من صحة `MEXC_API_KEY` و `MEXC_SECRET_KEY`
- تأكد من تفعيل صلاحيات التداول في MEXC API

### المشكلة: فشل البناء (Build Failed)

**الحل:**
- تحقق من أن `requirements.txt` موجود وصحيح
- تأكد من أن `runtime.txt` يحتوي على إصدار Python صحيح

## إيقاف البوت

لإيقاف البوت مؤقتًا:
1. انتقل إلى لوحة تحكم Render
2. اختر الخدمة
3. انقر على **Suspend**

لإيقاف البوت نهائيًا:
1. انتقل إلى إعدادات الخدمة
2. انقر على **Delete Service**

## التحديثات

عند إجراء تحديثات على الكود:
1. قم بعمل push للتغييرات إلى GitHub
2. سيقوم Render بإعادة النشر تلقائيًا

## الأمان

⚠️ **تحذيرات أمنية مهمة:**

- لا تشارك مفاتيح API أو التوكنات مع أي شخص
- استخدم مفاتيح API بصلاحيات محدودة (التداول فقط)
- راقب نشاط الحساب بانتظام
- ابدأ بمبالغ صغيرة للاختبار

## الدعم

في حالة وجود مشاكل:
1. راجع Logs في Render
2. تحقق من إعدادات المتغيرات البيئية
3. راجع ملف README.md للمزيد من المعلومات

---

**ملاحظة**: هذا البوت للاستخدام الشخصي. التداول يحمل مخاطر وقد تخسر رأس المال. استخدمه على مسؤوليتك الخاصة.
